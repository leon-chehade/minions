# Fartings

In order to hear the minions fart start the application and click the butts of the minions. 